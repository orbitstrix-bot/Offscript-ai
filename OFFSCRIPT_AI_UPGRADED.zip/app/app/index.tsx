import React, { useState } from "react";
import { Alert, Platform, ScrollView, Text, TextInput, TouchableOpacity, View, ActivityIndicator } from "react-native";
import * as DocumentPicker from "expo-document-picker";

const API = process.env.EXPO_PUBLIC_API_URL || (Platform.OS === "android" ? "http://10.0.2.2:8000" : "http://localhost:8000");
const C = {bg:"#080B12", panel:"#111827", panel2:"#182235", text:"#F8FAFC", muted:"#94A3B8", purple:"#8B5CF6", line:"#293449", green:"#34D399"};

function Btn({title,onPress,active=false}:any){return <TouchableOpacity onPress={onPress} style={{backgroundColor:active?C.purple:C.panel2,borderColor:active?C.purple:C.line,borderWidth:1,borderRadius:12,paddingVertical:12,paddingHorizontal:15,alignItems:"center",flex:1}}><Text style={{color:C.text,fontWeight:"700"}}>{title}</Text></TouchableOpacity>}
function Label({children}:any){return <Text style={{color:C.muted,fontSize:12,fontWeight:"700",letterSpacing:1,marginBottom:9,marginTop:20}}>{children}</Text>}
export default function Home(){
 const [url,setUrl]=useState(""); const [file,setFile]=useState<any>(null);
 const [count,setCount]=useState(10); const [duration,setDuration]=useState(60);
 const [ratio,setRatio]=useState("9:16"); const [subs,setSubs]=useState("animated");
 const [mode,setMode]=useState("viral"); const [face,setFace]=useState(true); const [busy,setBusy]=useState(false);
 const [titles,setTitles]=useState<any>({});
 const [job,setJob]=useState<any>(null); const [err,setErr]=useState("");
 const pick=async()=>{const r=await DocumentPicker.getDocumentAsync({type:"video/*",copyToCacheDirectory:true});if(!r.canceled){setFile(r.assets[0]);setUrl("");}};
 const submit=async()=>{
  if(!url.trim()&&!file){setErr("Paste a video URL or choose a video file.");return;}
  setBusy(true);setErr("");setJob(null);
  try{
   const data=new FormData();
   if(file){data.append("file",{uri:file.uri,name:file.name||"video.mp4",type:file.mimeType||"video/mp4"} as any);}
   else data.append("video_url",url.trim());
   data.append("clip_count",String(count));data.append("duration_seconds",String(duration));
   data.append("aspect_ratio",ratio);data.append("subtitle_style",subs);data.append("detection_mode",mode);data.append("face_tracking",String(face));
   const res=await fetch(`${API}/api/jobs`,{method:"POST",body:data});
   const body=await res.json();if(!res.ok)throw new Error(body.detail||"Could not create job.");
   setJob(body); poll(body.job_id);
  }catch(e:any){setErr(e.message||"Connection failed. Check the API URL and backend.");setBusy(false);}
 };
 const poll=async(id:string)=>{
  try{const r=await fetch(`${API}/api/jobs/${id}`);const j=await r.json();setJob(j);
   if(j.status==="queued"||j.status==="processing"){setTimeout(()=>poll(id),4000);}
   else {setBusy(false);if(j.status==="failed")setErr(j.error||"Processing failed.");}
  }catch(e:any){setBusy(false);setErr("Lost connection while checking job status.");}
 };
 const chips=(values:string[],value:string,set:(s:string)=>void)=> <View style={{flexDirection:"row",flexWrap:"wrap",gap:8}}>{values.map(v=><TouchableOpacity key={v} onPress={()=>set(v)} style={{paddingVertical:10,paddingHorizontal:14,borderRadius:10,backgroundColor:value===v?C.purple:C.panel2,borderWidth:1,borderColor:value===v?C.purple:C.line}}><Text style={{color:C.text,fontWeight:"600"}}>{v}</Text></TouchableOpacity>)}</View>;
 return <ScrollView style={{flex:1,backgroundColor:C.bg}} contentContainerStyle={{padding:20,paddingTop:Platform.OS==="web"?34:54,paddingBottom:60,maxWidth:760,width:"100%",alignSelf:"center"}}>
  <View style={{flexDirection:"row",alignItems:"center",justifyContent:"space-between"}}>
   <View><Text style={{color:C.text,fontSize:27,fontWeight:"900",letterSpacing:1}}>OFFSCRIPT<Text style={{color:C.purple}}> AI</Text></Text><Text style={{color:C.muted,fontSize:11,letterSpacing:2,marginTop:3}}>LONG VIDEOS IN. SHORTS OUT.</Text></View>
   <View style={{backgroundColor:"#12352D",padding:9,borderRadius:20}}><Text style={{color:C.green,fontSize:11,fontWeight:"800"}}>● AI CLIPPER</Text></View>
  </View>
  <View style={{backgroundColor:C.panel,borderRadius:20,padding:18,marginTop:24,borderWidth:1,borderColor:C.line}}>
   <Text style={{color:C.text,fontSize:23,fontWeight:"800"}}>Find the moments{"\n"}worth sharing.</Text>
   <Text style={{color:C.muted,marginTop:8,lineHeight:21}}>Add a recording or supported video link. OFFSCRIPT AI will transcribe, rank highlights and create short clips.</Text>
   <Label>VIDEO SOURCE</Label>
   <TextInput value={url} onChangeText={v=>{setUrl(v);if(v)setFile(null);}} placeholder="Paste a video URL…" placeholderTextColor="#64748B" autoCapitalize="none" style={{backgroundColor:C.bg,borderColor:C.line,borderWidth:1,borderRadius:12,padding:14,color:C.text}}/>
   <View style={{flexDirection:"row",alignItems:"center",gap:10,marginTop:10}}>
    <View style={{height:1,backgroundColor:C.line,flex:1}}/><Text style={{color:C.muted,fontSize:11}}>OR</Text><View style={{height:1,backgroundColor:C.line,flex:1}}/>
   </View>
   <TouchableOpacity onPress={pick} style={{marginTop:10,borderWidth:1,borderStyle:"dashed",borderColor:C.purple,borderRadius:12,padding:15,alignItems:"center"}}><Text style={{color:C.text,fontWeight:"700"}}>{file?`✓ ${file.name}`:"＋ Choose a video file"}</Text><Text style={{color:C.muted,fontSize:11,marginTop:4}}>MP4, MOV and other supported video formats</Text></TouchableOpacity>
   <Label>NUMBER OF CLIPS · {count}</Label>
   {chips(["1","5","10","15","20","25"],String(count),v=>setCount(Number(v)))}
   <Label>CLIP DURATION</Label>
   {chips(["30 sec","60 sec","90 sec","3 min","5 min","10 min"],({30:"30 sec",60:"60 sec",90:"90 sec",180:"3 min",300:"5 min",600:"10 min"} as any)[duration],v=>setDuration(({"30 sec":30,"60 sec":60,"90 sec":90,"3 min":180,"5 min":300,"10 min":600} as any)[v]))}
   <Label>VIDEO RATIO</Label>{chips(["9:16","16:9","1:1"],ratio,setRatio)}
   <Label>SUBTITLES</Label>{chips(["animated","simple","off"],subs,setSubs)}
   <Label>AI MOMENT DETECTION</Label>{chips(["viral","funny","emotional","educational"],mode,setMode)}
   <Label>SMART FACE TRACKING</Label>
   {chips(["on","off"],face?"on":"off",v=>setFace(v==="on"))}
   <Text style={{color:C.muted,fontSize:11,marginTop:7}}>Keeps the detected speaker in frame for vertical and square clips.</Text>
   <View style={{marginTop:18,backgroundColor:C.bg,borderRadius:12,padding:13,flexDirection:"row",justifyContent:"space-between",alignItems:"center"}}>
    <View><Text style={{color:C.text,fontWeight:"700"}}>No added watermark</Text><Text style={{color:C.muted,fontSize:11,marginTop:3}}>Exports contain no OFFSCRIPT branding</Text></View><Text style={{color:C.green,fontWeight:"900"}}>✓ ON</Text>
   </View>
   <TouchableOpacity disabled={busy} onPress={submit} style={{marginTop:18,backgroundColor:busy?"#51417A":C.purple,borderRadius:13,padding:16,alignItems:"center",flexDirection:"row",justifyContent:"center",gap:9}}>
    {busy?<ActivityIndicator color="white"/>:<Text style={{color:"white",fontSize:16,fontWeight:"800"}}>✦  Find viral moments</Text>}
   </TouchableOpacity>
   {err?<Text style={{color:"#FCA5A5",marginTop:12}}>{err}</Text>:null}
  </View>
  {job&&<View style={{backgroundColor:C.panel,borderRadius:18,padding:17,marginTop:18,borderWidth:1,borderColor:C.line}}>
   <Text style={{color:C.text,fontSize:18,fontWeight:"800"}}>Your clipping job</Text>
   <Text style={{color:C.muted,marginTop:7}}>Job ID: {job.job_id}</Text>
   <Text style={{color:job.status==="completed"?C.green:C.purple,marginTop:8,fontWeight:"800"}}>{String(job.status||"").toUpperCase()}</Text>
   {job.status==="completed"?(job.clips||[]).map((clip:any)=><View key={clip.id} style={{paddingVertical:12,borderTopWidth:1,borderColor:C.line,marginTop:8}}>
    <Text style={{color:C.text,fontWeight:"700"}}>Clip {clip.id} · {clip.duration_seconds}s · AI score {clip.viral_score}/99</Text>
    <TextInput value={titles[clip.id]??clip.title} onChangeText={v=>setTitles((t:any)=>({...t,[clip.id]:v}))} style={{color:C.text,backgroundColor:C.bg,borderRadius:8,padding:10,marginTop:8,borderWidth:1,borderColor:C.line}} placeholder="Edit clip title"/>
    <Text style={{color:C.muted,marginTop:6}}>Hook: {clip.hook}</Text>
    <Text style={{color:C.muted,fontSize:11,marginTop:4}}>Face tracking: {clip.face_tracking?"Applied":"Center crop fallback"}</Text>
    {Platform.OS==="web"?<View style={{marginTop:10}}>{React.createElement("video" as any,{controls:true,playsInline:true,src:API+clip.url,style:{width:"100%",maxHeight:420,borderRadius:10,backgroundColor:"#000"}})}</View>:null}
    <View style={{flexDirection:"row",flexWrap:"wrap",gap:8,marginTop:10}}>
     <Text onPress={()=>{const u=API+clip.url;if(Platform.OS==="web")window.open(u,"_blank");}} style={{color:"#A78BFA",fontWeight:"700"}}>Preview / Download ↗</Text>
     <Text style={{color:C.muted}}>·</Text><Text style={{color:C.green}}>No added watermark</Text>
    </View>
    <Text style={{color:C.muted,fontSize:10,marginTop:8}}>Export-ready profiles: YouTube Shorts · Instagram Reels · TikTok</Text>
   </View>):<Text style={{color:C.muted,marginTop:8}}>Transcribing and analysing your video. This can take a while on CPU.</Text>}
  </View>}
  <Text style={{color:"#64748B",fontSize:11,textAlign:"center",marginTop:22,lineHeight:17}}>OFFSCRIPT AI · Built for creators{"\n"}Only process media you own or have permission to use.</Text>
 </ScrollView>;
}
