import os, re, subprocess
from pathlib import Path

def run(cmd):
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if proc.returncode:
        raise RuntimeError(proc.stderr[-2500:] or "Media processing failed.")
    return proc.stdout.strip()

def download_source(source, is_url, work):
    if not is_url:
        p=Path(source)
        if not p.exists(): raise RuntimeError("Uploaded source file was not found.")
        return p
    template=str(work/"source.%(ext)s")
    run(["yt-dlp","--no-playlist","-f","bv*+ba/b","--merge-output-format","mp4","-o",template,source])
    candidates=[p for p in work.glob("source.*") if p.suffix.lower() not in (".part",".ytdl")]
    if not candidates: raise RuntimeError("Could not retrieve video. Try an authorized video URL or upload.")
    return candidates[0]

def duration_of(video):
    return float(run(["ffprobe","-v","error","-show_entries","format=duration","-of","default=noprint_wrappers=1:nokey=1",str(video)]))

def transcribe(video):
    from faster_whisper import WhisperModel
    model=WhisperModel(os.getenv("WHISPER_MODEL","small"),device=os.getenv("WHISPER_DEVICE","cpu"),compute_type=os.getenv("WHISPER_COMPUTE_TYPE","int8"))
    segments,info=model.transcribe(str(video),vad_filter=True,word_timestamps=True)
    result=[]
    for seg in segments:
        words=[]
        for w in (seg.words or []):
            words.append({"start":float(w.start),"end":float(w.end),"word":w.word.strip()})
        result.append({"start":float(seg.start),"end":float(seg.end),"text":seg.text.strip(),"words":words})
    return result

def score_segment(seg, mode):
    text=seg["text"].lower()
    hooks=["but","however","secret","never","best","worst","why","how","amazing","unbelievable","mistake","truth","actually","important","finally","because","shocking","love","hate","wow"]
    score=min(1.0,.18+sum(.09 for w in hooks if re.search(r"\b"+re.escape(w)+r"\b",text)))
    if "?" in text: score+=.12
    if "!" in text: score+=.08
    keywords={"funny":["haha","laugh","funny","joke"],"emotional":["feel","love","lost","heart","cry"],"educational":["learn","step","first","example","because"]}
    if mode in keywords and any(w in text for w in keywords[mode]): score+=.3
    return score

def write_ass(transcript,start,end,path,style):
    # Karaoke-style word highlighting using ASS \kf tags.
    header="""[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Arial,68,&H00FFFFFF,&H0000D7FF,&H00000000,&H80000000,1,0,0,0,100,100,0,0,1,4,1,2,70,70,180,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    def ts(t):
        cs=max(0,int(t*100)); h=cs//360000; m=(cs//6000)%60; sec=(cs//100)%60; cent=cs%100
        return f"{h}:{m:02}:{sec:02}.{cent:02}"
    events=[]
    for seg in transcript:
        if seg["end"]<=start or seg["start"]>=end: continue
        words=[w for w in seg.get("words",[]) if w["end"]>start and w["start"]<end]
        if not words:
            txt=seg["text"].replace("{","").replace("}","")
            events.append(f"Dialogue: 0,{ts(max(0,seg['start']-start))},{ts(min(end,seg['end'])-start)},Default,,0,0,0,,{txt}")
            continue
        chunks=[]
        for w in words:
            dur=max(1,int((min(w["end"],end)-max(w["start"],start))*100))
            token=w["word"].replace("{","").replace("}","")
            chunks.append(r"{\kf"+str(dur)+"}"+token)
        events.append(f"Dialogue: 0,{ts(max(0,words[0]['start']-start))},{ts(min(end,words[-1]['end'])-start)},Default,,0,0,0,,{' '.join(chunks)}")
    Path(path).write_text(header+"\n".join(events),encoding="utf-8")

def face_track_render(video,dest,start,duration,ratio):
    """Center crop around detected faces. Falls back to FFmpeg crop if OpenCV has no face."""
    try:
        import cv2
        import numpy as np
        cap=cv2.VideoCapture(str(video))
        fps=cap.get(cv2.CAP_PROP_FPS) or 30
        sw=int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)); sh=int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        if ratio=="9:16": outw,outh=720,1280
        elif ratio=="1:1": outw,outh=720,720
        else: outw,outh=1280,720
        target=outw/outh
        if sw/sh>target: crop_h=sh; crop_w=int(sh*target)
        else: crop_w=sw; crop_h=int(sw/target)
        detector=cv2.CascadeClassifier(cv2.data.haarcascades+"haarcascade_frontalface_default.xml")
        cap.set(cv2.CAP_PROP_POS_MSEC,start*1000)
        writer=cv2.VideoWriter(str(dest),cv2.VideoWriter_fourcc(*"mp4v"),fps,(outw,outh))
        frames=int(duration*fps); cx=sw/2; cy=sh/2
        for _ in range(frames):
            ok,frame=cap.read()
            if not ok: break
            gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
            faces=detector.detectMultiScale(gray,1.2,5,minSize=(40,40))
            if len(faces):
                x,y,w,h=max(faces,key=lambda f:f[2]*f[3])
                tx=x+w/2; ty=y+h/2
                cx=cx*.78+tx*.22; cy=cy*.78+ty*.22
            x0=max(0,min(sw-crop_w,int(cx-crop_w/2))); y0=max(0,min(sh-crop_h,int(cy-crop_h/2)))
            crop=frame[y0:y0+crop_h,x0:x0+crop_w]
            writer.write(cv2.resize(crop,(outw,outh)))
        cap.release(); writer.release()
        if not os.path.exists(dest) or os.path.getsize(dest)<1000: raise RuntimeError("Face tracking render empty")
        return True
    except Exception:
        return False

def process_video(source,is_url,output_dir,options):
    outdir=Path(output_dir); outdir.mkdir(parents=True,exist_ok=True)
    work=outdir/"work"; work.mkdir(exist_ok=True)
    video=download_source(source,is_url,work); total=duration_of(video)
    if total<30: raise RuntimeError("Source video must be at least 30 seconds.")
    transcript=transcribe(video)
    if not transcript: raise RuntimeError("No speech detected.")
    target=min(options["duration_seconds"],int(total))
    mode=options.get("detection_mode","viral")
    candidates=[]
    for seg in transcript:
        st=max(0,min(seg["start"]-target*.18,total-target)); en=st+target
        nearby=[s for s in transcript if s["start"]<en and s["end"]>st]
        if not nearby: continue
        avg=sum(score_segment(s,mode) for s in nearby)/len(nearby)
        density=min(1,len(" ".join(s["text"] for s in nearby))/max(100,target*2.2))
        candidates.append((avg*.75+density*.25,st,en,nearby))
    candidates.sort(reverse=True,key=lambda x:x[0])
    chosen=[]
    for item in candidates:
        _,st,en,_=item
        if all(en<=x[1] or st>=x[2] for x in chosen): chosen.append(item)
        if len(chosen)>=options["clip_count"]: break
    clips=[]
    for i,(score,st,en,nearby) in enumerate(chosen,1):
        name=f"clip_{i:02}.mp4"; dest=outdir/name
        ratio=options["aspect_ratio"]
        temp=outdir/f"base_{i:02}.mp4"
        tracked=False
        if options.get("face_tracking",True):
            tracked=face_track_render(video,temp,st,en-st,ratio)
        if tracked:
            # OpenCV writes video-only output; mux the matching source audio segment.
            silent=outdir/f"tracked_silent_{i:02}.mp4"
            os.replace(temp,silent)
            run(["ffmpeg","-y","-ss",str(st),"-i",str(video),"-i",str(silent),"-t",str(en-st),
                 "-map","1:v:0","-map","0:a?","-c:v","copy","-c:a","aac","-shortest",str(temp)])
            silent.unlink(missing_ok=True)
        if not tracked:
            if ratio=="9:16": vf="scale=720:1280:force_original_aspect_ratio=increase,crop=720:1280"
            elif ratio=="1:1": vf="scale=720:720:force_original_aspect_ratio=increase,crop=720:720"
            else: vf="scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2"
            run(["ffmpeg","-y","-ss",str(st),"-i",str(video),"-t",str(en-st),"-vf",vf,"-c:v","libx264","-preset","veryfast","-crf","23","-c:a","aac",str(temp)])
        if options["subtitle_style"]!="off":
            ass=outdir/f"clip_{i:02}.ass"; write_ass(transcript,st,en,ass,options["subtitle_style"])
            escaped=str(ass).replace("\\","\\\\").replace(":","\\:").replace("'","\\'")
            run(["ffmpeg","-y","-i",str(temp),"-vf",f"ass='{escaped}'","-c:v","libx264","-preset","veryfast","-crf","22","-c:a","copy",str(dest)])
        else: shutil_copy(temp,dest)
        excerpt=" ".join(s["text"] for s in nearby)
        title=make_title(excerpt,mode)
        clips.append({"id":i,"filename":name,"url":f"/media/{outdir.name}/{name}",
          "start_seconds":round(st,1),"end_seconds":round(en,1),"duration_seconds":round(en-st,1),
          "viral_score":round(min(99,score*100),1),"title":title,"hook":make_hook(excerpt),
          "transcript_excerpt":excerpt[:500],"face_tracking":tracked,
          "export_profiles":["YouTube Shorts","Instagram Reels","TikTok"]})
    return clips

def shutil_copy(src,dest):
    import shutil
    shutil.copyfile(src,dest)

def make_hook(text):
    clean=" ".join(text.split())
    words=clean.split()
    return " ".join(words[:9]) + ("…" if len(words)>9 else "")

def make_title(text,mode):
    words=re.findall(r"\b[\w'-]+\b",text)
    title=" ".join(words[:8]).strip().capitalize()
    if not title: title={"funny":"The funniest moment","emotional":"A moment to remember","educational":"A lesson worth learning"}.get(mode,"The moment you need to see")
    return title[:75]
