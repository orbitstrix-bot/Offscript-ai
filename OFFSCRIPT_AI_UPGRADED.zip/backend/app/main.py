import os, uuid, shutil, asyncio
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, UploadFile, File, Form, BackgroundTasks, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from .pipeline import process_video

BASE = Path(os.getenv("OFFSCRIPT_DATA", "../data")).resolve()
UPLOADS = BASE / "uploads"
OUTPUTS = BASE / "outputs"
UPLOADS.mkdir(parents=True, exist_ok=True)
OUTPUTS.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="OFFSCRIPT AI API", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=True,
    allow_methods=["*"], allow_headers=["*"],
)
app.mount("/media", StaticFiles(directory=str(OUTPUTS)), name="media")

# MVP in-memory registry. Replace with PostgreSQL + Redis/Celery for production.
JOBS = {}

@app.get("/health")
def health():
    return {"ok": True, "service": "OFFSCRIPT AI"}

async def run_job(job_id: str, source: str, is_url: bool, options: dict):
    JOBS[job_id]["status"] = "processing"
    try:
        result = await asyncio.to_thread(
            process_video, source, is_url, str(OUTPUTS / job_id), options
        )
        JOBS[job_id].update(status="completed", clips=result, progress=100)
    except Exception as exc:
        JOBS[job_id].update(status="failed", error=str(exc))

@app.post("/api/jobs")
async def create_job(
    background_tasks: BackgroundTasks,
    video_url: Optional[str] = Form(None),
    file: Optional[UploadFile] = File(None),
    clip_count: int = Form(10),
    duration_seconds: int = Form(60),
    aspect_ratio: str = Form("9:16"),
    subtitle_style: str = Form("animated"),
    detection_mode: str = Form("viral"),
    face_tracking: bool = Form(True),
):
    if not video_url and not file:
        raise HTTPException(400, "Provide a video URL or upload a video file.")
    if video_url and file:
        raise HTTPException(400, "Choose either a URL or a file, not both.")
    if not 1 <= clip_count <= 25:
        raise HTTPException(400, "clip_count must be between 1 and 25.")
    if not 30 <= duration_seconds <= 600:
        raise HTTPException(400, "duration_seconds must be between 30 and 600.")
    if aspect_ratio not in ("9:16", "16:9", "1:1"):
        raise HTTPException(400, "Unsupported aspect ratio.")
    if subtitle_style not in ("off", "simple", "animated"):
        raise HTTPException(400, "Unsupported subtitle style.")

    job_id = uuid.uuid4().hex[:12]
    job_dir = UPLOADS / job_id
    job_dir.mkdir(parents=True, exist_ok=True)

    if file:
        suffix = Path(file.filename or "upload.mp4").suffix or ".mp4"
        source = job_dir / ("source" + suffix)
        with source.open("wb") as out:
            shutil.copyfileobj(file.file, out)
        source_value, is_url = str(source), False
        source_label = file.filename
    else:
        source_value, is_url = video_url.strip(), True
        source_label = video_url.strip()

    options = {
        "clip_count": clip_count,
        "duration_seconds": duration_seconds,
        "aspect_ratio": aspect_ratio,
        "subtitle_style": subtitle_style,
        "detection_mode": detection_mode,
        "face_tracking": face_tracking,
    }
    JOBS[job_id] = {
        "job_id": job_id, "status": "queued", "progress": 0,
        "source": source_label, "options": options, "clips": [],
    }
    background_tasks.add_task(run_job, job_id, source_value, is_url, options)
    return JOBS[job_id]

@app.get("/api/jobs/{job_id}")
def get_job(job_id: str):
    if job_id not in JOBS:
        raise HTTPException(404, "Job not found.")
    return JOBS[job_id]

@app.get("/api/jobs/{job_id}/clips")
def get_clips(job_id: str):
    if job_id not in JOBS:
        raise HTTPException(404, "Job not found.")
    return {"clips": JOBS[job_id].get("clips", [])}
