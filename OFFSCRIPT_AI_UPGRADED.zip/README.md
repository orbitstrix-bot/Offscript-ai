# OFFSCRIPT AI

A cross-platform starter MVP for AI-assisted short-form video clipping.

## Included
- Expo app targeting Android and web
- Video URL and local-file input UI
- Clip count (1–25), duration (30–600 seconds), aspect ratio, subtitle options
- FastAPI backend with job creation/status endpoints
- Worker pipeline using yt-dlp, FFmpeg and faster-whisper
- Transcript-based highlight scoring and clip rendering
- Face-aware crop tracking (OpenCV Haar cascade, with center-crop fallback)
- Word-timed karaoke-style subtitle highlighting
- AI-assisted hook/title suggestions (heuristic, editable in the app)
- In-app web preview and export-ready social aspect-ratio profiles
- No branding/watermark overlay is added to exported clips

## Important limitations
- This is a runnable MVP starter, not a hosted production service.
- Live-stream clipping is not implemented as continuous ingest yet. The backend currently accepts recorded videos and supported downloadable video URLs. A live-stream connector/ingest worker is a separate deployment step.
- "Unlimited" means no artificial lifetime job counter in this code. Real concurrency, storage and throughput are limited by your server resources.
- Viral scores and suggested hooks/titles are heuristic estimates, not predictions or guarantees of views.
- Face tracking uses a lightweight face detector and may not track reliably with multiple people, occlusion, or low light. It is not a production-grade ML tracker.
- Social export profiles currently mean aspect-ratio-ready exports and labels; direct publishing to social accounts is not connected.
- Only process videos you own or are authorized to use. Some platforms restrict downloading or processing; use their permitted export/API methods.
- No watermark is added by this app. This does not remove watermarks already present in source media.

## Run backend (Python 3.11 recommended)
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
# Install FFmpeg and ensure `ffmpeg` and `ffprobe` are on PATH.
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Optional faster-whisper model is downloaded on first use. CPU mode is the default.

## Run app
```bash
cd app
npm install
npx expo start
```
- Press `w` for web.
- Scan the QR code with Expo Go for Android during development.
- For a standalone Android APK, configure EAS Build:
  `npm install -g eas-cli && eas build -p android --profile preview`

## Connect app to backend
Set `EXPO_PUBLIC_API_URL`:
- Android emulator: `http://10.0.2.2:8000`
- Physical Android phone: `http://YOUR_COMPUTER_LAN_IP:8000`
- Web on same computer: `http://localhost:8000`

Example:
```bash
EXPO_PUBLIC_API_URL=http://localhost:8000 npx expo start
```

## API
- `POST /api/jobs` multipart form: `video_url` OR `file`, plus `clip_count`, `duration_seconds`, `aspect_ratio`, `subtitle_style`, `detection_mode`
- `GET /api/jobs/{job_id}`
- `GET /api/jobs/{job_id}/clips`
- `GET /health`

Jobs are stored in memory in this MVP. Use PostgreSQL/Redis + a durable worker queue before public deployment.
